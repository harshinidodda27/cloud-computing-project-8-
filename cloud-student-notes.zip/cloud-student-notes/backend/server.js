require("dotenv").config();

const express = require("express");
const cors = require("cors");

const db = require("./db");
const authRoutes = require("./routes/authRoutes");
const notesRoutes = require("./routes/notesRoutes");

const app = express();

const PORT = process.env.PORT || 5000;


// ==========================================
// MIDDLEWARE
// ==========================================

app.use(cors());

app.use(express.json());


// ==========================================
// HOME ROUTE
// ==========================================

app.get("/", (req, res) => {
    res.json({
        message: "Cloud Student Notes API is running!"
    });
});


// ==========================================
// DATABASE TEST ROUTE
// ==========================================

app.get("/api/test-db", (req, res) => {

    db.query(
        "SELECT 1 AS test",
        (err, results) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    message: "Database connection failed"
                });
            }

            res.json({
                message: "Database connected successfully!",
                result: results
            });
        }
    );

});


// ==========================================
// AUTHENTICATION ROUTES
// ==========================================

app.use(
    "/api/auth",
    authRoutes
);


// ==========================================
// NOTES ROUTES
// ==========================================

app.use(
    "/api/notes",
    notesRoutes
);


// ==========================================
// START SERVER
// ==========================================

app.listen(PORT, () => {

    console.log(
        `🚀 Server running at http://localhost:${PORT}`
    );

}); 