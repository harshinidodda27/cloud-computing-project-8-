const express = require("express");
const multer = require("multer");
const path = require("path");
const db = require("../db");

const router = express.Router();


// ==========================================
// FILE UPLOAD CONFIGURATION
// ==========================================

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, "../uploads"));
    },

    filename: (req, file, cb) => {
        const uniqueName =
            Date.now() + "-" + file.originalname;

        cb(null, uniqueName);
    }
});

const upload = multer({
    storage: storage
});


// ==========================================
// ADD NOTE WITH FILE
// ==========================================

router.post("/add", upload.single("file"), (req, res) => {

    const {
        student_id,
        title,
        description
    } = req.body;

    // Check required fields
    if (!student_id || !title) {
        return res.status(400).json({
            message: "Please provide student_id and title"
        });
    }

    // Get uploaded filename
    const filename = req.file
        ? req.file.filename
        : null;

    const sql = `
        INSERT INTO notes
        (student_id, title, description, filename)
        VALUES (?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            student_id,
            title,
            description || null,
            filename
        ],
        (err, result) => {

            if (err) {
                console.error(err);

                return res.status(500).json({
                    message: "Failed to add note"
                });
            }

            res.status(201).json({
                message: "Note uploaded successfully",
                noteId: result.insertId,
                filename: filename
            });
        }
    );
});


// ==========================================
// VIEW NOTES
// ==========================================

router.get("/student/:student_id", (req, res) => {

    const studentId = req.params.student_id;

    const sql = `
        SELECT
            id,
            title,
            description,
            filename,
            created_at
        FROM notes
        WHERE student_id = ?
        ORDER BY created_at DESC
    `;

    db.query(
        sql,
        [studentId],
        (err, results) => {

            if (err) {
                console.error(err);

                return res.status(500).json({
                    message: "Failed to fetch notes"
                });
            }

            res.json({
                message: "Notes fetched successfully",
                notes: results
            });
        }
    );
});


// ==========================================
// DOWNLOAD NOTE FILE
// ==========================================

router.get("/download/:filename", (req, res) => {

    const filename = req.params.filename;

    const filePath = path.join(
        __dirname,
        "../uploads",
        filename
    );

    res.download(filePath, (err) => {

        if (err) {
            console.error(err);

            if (!res.headersSent) {
                res.status(404).json({
                    message: "File not found"
                });
            }
        }
    });
});


// ==========================================
// DELETE NOTE
// ==========================================

router.delete("/:id", (req, res) => {

    const noteId = req.params.id;

    // First get the filename
    const selectSql = `
        SELECT filename
        FROM notes
        WHERE id = ?
    `;

    db.query(
        selectSql,
        [noteId],
        (err, results) => {

            if (err) {
                console.error(err);

                return res.status(500).json({
                    message: "Failed to find note"
                });
            }

            if (results.length === 0) {
                return res.status(404).json({
                    message: "Note not found"
                });
            }

            const filename = results[0].filename;

            // Delete database record
            const deleteSql = `
                DELETE FROM notes
                WHERE id = ?
            `;

            db.query(
                deleteSql,
                [noteId],
                (err, result) => {

                    if (err) {
                        console.error(err);

                        return res.status(500).json({
                            message: "Failed to delete note"
                        });
                    }

                    res.json({
                        message: "Note deleted successfully",
                        deletedFile: filename
                    });
                }
            );
        }
    );
});


module.exports = router; 